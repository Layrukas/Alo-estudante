/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interfaces;
import codigos.*;
import java.time.LocalDate;
/**
 *
 * @author 08050486
 */
public class Main {
    public static void main(String[] args){
        EmpresaDAO em = EmpresaDAO.getInstance();
        Empresa empresa = new Empresa("Apple","74019084000141","rua do casacao", "12", "albatroz","tramandai","Rs","23949023900","a@a.com","TESTE",123);
        EstagiarioDAO estdao = EstagiarioDAO.getInstance();
        LocalDate data = LocalDate.now();
        Estagiario est = new Estagiario("Rodolfo",data,"01777901057","tadala","Albatroz","12","Osorio","Rio Grande do Sul",124);
        em.inserir(empresa);
        estdao.inserir(est);
        new FramePaginaLogin().setVisible(true);
        
    }   
    
}
