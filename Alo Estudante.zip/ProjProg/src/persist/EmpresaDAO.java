/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;
import codigos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 08050486
 */
public class EmpresaDAO implements DAO {
     private static EmpresaDAO empdao;
    private static Connection conexao;

    public static EmpresaDAO getInstance() {
        if (empdao == null) {
            empdao = new EmpresaDAO();
        }
        return empdao;
    }
    
     private EmpresaDAO() {
        ConexaoBD conexaoBD;

        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }

     @Override
     public boolean inserir(Object obj) {
          if (obj != null && obj instanceof Empresa) {
              Empresa e = (Empresa) obj;
              String nome = e.getNome_empresa();
              String cnpj = e.getCnpj();
              Integer senha = e.getSenha();
              String email = e.getEmail();
              String descricao = e.getDescricao();
              String rua = e.getRuaEmpre();
              String bairro = e.getBairroEmpre();
              String cidade = e.getCidadeEmpre();
              String estado = e.getEstadoEmpre();
              String numero = e.getNumeroEmpre();
              String telefone = e.getTelefone_empresa();
              
              String sql = "INSERT INTO empresa (nome_empresa, cnpj, senha_empresa, email, descricao,rua,numero,bairro,cidade,estado,telefone_empresa)" + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
              
              try{
                  PreparedStatement pstmt = conexao.prepareStatement(sql);
                  pstmt.setString(1,nome);
                  pstmt.setString(2, cnpj);
                  pstmt.setInt(3, senha);
                  pstmt.setString(4,email);
                  pstmt.setString(5,descricao);
                  pstmt.setString(6,rua);
                  pstmt.setString(7,numero);
                  pstmt.setString(8,bairro);
                  pstmt.setString(9,cidade);
                  pstmt.setString(10,estado);
                  pstmt.setString(11,telefone);
                  pstmt.executeUpdate();
                  return true;
              } catch(SQLException sqe){
                  System.out.println("Erro = " + sqe);
              }
          }
         return false;
     }

    @Override
    public boolean excluir(Object obj) {
        if (obj != null && obj instanceof String) {
            try {
                String cnpj = (String) obj;
                String sql = "DELETE FROM empresa WHERE cnpj = '" + cnpj + "'";
                Statement stmt = conexao.createStatement();
                int nreg = stmt.executeUpdate(sql);
                if (nreg > 0) {
                    return true;
                }
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        if(obj !=  null && obj instanceof Empresa){
            try{
                Empresa p = (Empresa) obj;
                String sql = "UPDATE empresa SET nome_empresa = ? , descricao = ? , rua = ? , numero = ? , bairro = ? , cidade = ? , estado = ? , senha_empresa = ? , email = ? , telefone_empresa = ? WHERE cnpj = ?";
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1,p.getNome_empresa());
                pstmt.setString(2,p.getDescricao());
                pstmt.setString(3,p.getRuaEmpre());
                pstmt.setString(4,p.getNumeroEmpre());
                pstmt.setString(5,p.getBairroEmpre());
                pstmt.setString(6, p.getCidadeEmpre());
                pstmt.setString(7,p.getEstadoEmpre());
                pstmt.setInt(8,p.getSenha());
                pstmt.setString(9, p.getEmail());
                pstmt.setString(10,p.getTelefone_empresa());
                pstmt.setString(11, p.getCnpj());
                pstmt.executeUpdate();
                return true;
            }catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public Object pesquisar(Object obj) {
        if(obj != null && obj instanceof String){
            try{
                String cnpj = (String) obj;
                String sql = "SELECT * FROM empresa WHERE cnpj = '" + cnpj +"'";
                Statement stml = conexao.createStatement();
                ResultSet rs = stml.executeQuery(sql);
                if(rs.isBeforeFirst()){
                    rs.next();
                    int idEmp = rs.getInt(1);
                    String nome_empresa = rs.getString(2);
                    String rua =rs.getString(4);
                    String numero = rs.getString(5);
                    String bairro = rs.getString(6);
                    String cidade = rs.getString(7);
                    String estado = rs.getString(8);
                    String telefone = rs.getString(9);
                    String descricao = rs.getString(10);
                    String email = rs.getString(11);
                    Integer senha = rs.getInt(12);
                    
                    Empresa m = new Empresa(nome_empresa, cnpj,rua,numero,bairro,cidade,estado,telefone,email,descricao,senha);
                    m.setId(idEmp);
                    return m;
                }
            }catch(SQLException ex){
                System.out.println("Erro = "+ ex);
        }
      }
        return null;
    }

//    private int idEmpre;
//    private String nome_empresa;
//    private String cnpj;
//    private String ruaEmpre;
//    private String bairroEmpre;
//    private String numeroEmpre;
//    private String cidadeEmpre;
//    private String estadoEmpre; 
//    private String telefone_empresa;
//    private String email;
//    private String descricao;
//    private Integer senha;
    public ArrayList<Empresa> retornaTudo(){
        ArrayList<Empresa> lista = new ArrayList();
        try{
            String sql = "SELECT * FROM empresa";
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                int idEmpre = rs.getInt(1);
                String nome_empresa = rs.getString(2);
                String cnpj = rs.getString(3);
                String rua = rs.getString(4);
                String numero = rs.getString(5);
                String bairro = rs.getString(6);
                String cidade = rs.getString(7);
                String estado = rs.getString(8);
                String telefone = rs.getString(9);
                String descricao = rs.getString(10);
                String email = rs.getString(11);
                Integer senha = rs.getInt(12);
                Empresa emp = new Empresa(nome_empresa,cnpj,rua,bairro,numero,cidade,estado,telefone,descricao,email,senha);
                emp.setId(idEmpre);
                lista.add(emp);
            }
            return lista;
        }catch(SQLException sqe){
            System.out.println("Erro = " + sqe);
        }
        return null;
    }
}
