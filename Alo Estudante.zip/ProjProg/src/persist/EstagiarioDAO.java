/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;

import codigos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class EstagiarioDAO implements DAO {
    private EmpresaDAO empdao;
    private static EstagiarioDAO estdao;
    private static Connection conexao;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    
     public static EstagiarioDAO getInstance() {
        if (estdao == null) {
            estdao = new EstagiarioDAO();
        }
        return estdao;
    }
     
     private EstagiarioDAO() {
        ConexaoBD conexaoBD;
        this.empdao = EmpresaDAO.getInstance();
        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }

    @Override
    public boolean inserir(Object obj) {
        if (obj != null && obj instanceof Estagiario) {
              Estagiario es = (Estagiario) obj;
              Integer idEst = es.getIdEst();
              String nome = es.getNome();
              String cpf = es.getCpf();
              Integer senha = es.getSenha();
              String estado = es.getEstado();
              String cidade = es.getCidade();
              String bairro = es.getBairro();
              String rua = es.getRua();
              String numero = es.getNumero();
              LocalDate dataNasc = es.getDataNasc();
             
              String sql = "INSERT INTO estagiario (nome, cpf, senha, rua, bairro,numero,cidade,estado, data)" + "VALUES (?,?,?,?,?,?,?,?,?)";
               
              try{
                  PreparedStatement pstmt = conexao.prepareStatement(sql);
                  
                  pstmt.setString(1,nome);
                  pstmt.setString(2, cpf);
                  pstmt.setInt(3,senha);
                  pstmt.setString(4, rua);
                  pstmt.setString(5,bairro);
                  pstmt.setString(6,numero);
                  pstmt.setString(7,cidade);
                  pstmt.setString(8,estado);
                  pstmt.setString(9,es.getDataNascAsString());
                  pstmt.executeUpdate();
                  return true;
              } catch(SQLException sqe){
                  System.out.println("Erro = " + sqe);
              }
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
         if (obj != null && obj instanceof String) {
            try {
                String cpf = (String) obj;
                String sql = "DELETE FROM estagiario WHERE cpf = '" + cpf + "'";
                Statement stmt = conexao.createStatement();
                int nreg = stmt.executeUpdate(sql);
                if (nreg > 0) {
                    return true;
                }
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        if (obj != null && obj instanceof Estagiario) {
            try {
                Estagiario p = (Estagiario) obj;
                //(nome, cpf, senha, rua, bairro,numero,cidade,estado, data)
                
                String sql = "UPDATE estagiario SET nome = ?, data = ?, rua = ?, numero = ?, bairro = ?, cidade = ?, estado = ? ,senha = ?  WHERE cpf = ?";
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1, p.getNome());
                pstmt.setString(2, p.getDataNascAsString());
                pstmt.setString(3, p.getRua());
                pstmt.setString(4,p.getNumero());
                pstmt.setString(5,p.getBairro());
                pstmt.setString(6,p.getCidade());
                pstmt.setString(7,p.getEstado());
                pstmt.setInt(8,p.getSenha());
                pstmt.setString(9, p.getCpf());
                pstmt.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }
        @Override
    //Em obj estará o cpf
    public Object pesquisar(Object obj) {
        if (obj != null && obj instanceof String) {
            try {
                String cpf = (String) obj;
                String sql = "SELECT * FROM estagiario WHERE cpf = '" + cpf + "'";
                Statement stmt = conexao.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                if (rs.isBeforeFirst()) { //verifica se resultou algo da pesquisa
                    rs.next();
                    int idEst = rs.getInt(1);
                    String nome = rs.getString(2);
                    String dataNasc = rs.getString(3);
                    String rua = rs.getString(5);
                    String bairro = rs.getString(6);
                    String numero = rs.getString(7);
                    String cidade = rs.getString(8);
                    String estado = rs.getString(9);
                    Integer senha = rs.getInt(10);
                    
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate data = LocalDate.parse(dataNasc, formatter);
                    
                    Estagiario estag = new Estagiario(nome, data, cpf, rua, bairro, numero, cidade, estado, senha);
                    estag.setIdEst(idEst);
                    return estag;
                } 
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
       }
    } 
        return null;
  }    
//    public ArrayList<Pessoa> pesquisarTudo() {
//        ArrayList<Pessoa> lista = new ArrayList<>();
//        try {
//            String sql = "SELECT * FROM tbpessoa";
//            Statement stmt = conexao.createStatement();
//            ResultSet rs = stmt.executeQuery(sql);
//            while (rs.next()) {
//                int id = rs.getInt(1);
//                String login = rs.getString(2);
//                String cpf = login;
//                String senha = rs.getString(3);
//                int tipoUsuario = rs.getInt(4);
//                String nome = rs.getString(5);
//                char sexo = (rs.getString(6)).charAt(0);
//                String dataNascimento = rs.getString(7);
//                DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//                LocalDate data = LocalDate.parse(dataNascimento, formato);
//                Pessoa p = new Pessoa(cpf, nome, data, sexo);
//                p.setId(id);
//                Usuario user = new Usuario(login, senha);
//                p.setUser(user);
//                lista.add(p);
//            }
//            return lista;
//        } catch (SQLException sqe) {
//            System.out.println("Erro = " + sqe);
//        }
//        return null;
//    }
//     private int idEst;
//    private String nome;
//    private LocalDate dataNasc;
//    private String cpf;
//    private String rua;
//    private String bairro;
//    private String numero;
//    private String cidade;
//    private String estado;
//    private Integer senha;
//    private Empresa emp;
//    private boolean trabalhando;
    public ArrayList<Estagiario> retornaTudo(){
        ArrayList<Estagiario> lista = new ArrayList();
        try{
            String sql = "SELECT * FROM estagiario";
            Statement stmt = conexao.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                int idEst = rs.getInt(1);
                String nome = rs.getString(2);
                String dataNasc = rs.getString(3);
                String cpf = rs.getString(4);
                String rua = rs.getString(5);
                String bairro = rs.getString(6);
                String numero = rs.getString(7);
                String cidade = rs.getString(8);
                String estado = rs.getString(9);
                Integer senha = rs.getInt(10);
                String empresaCnpj = rs.getString(11);
                Empresa a = (Empresa) this.empdao.pesquisar(empresaCnpj);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate data = LocalDate.parse(dataNasc, formatter);
                Estagiario o = new Estagiario(nome,data,cpf, rua ,bairro, numero,cidade,estado,senha);
                if(a != null){
                    o.setEmp(a);
                }
                o.setIdEst(idEst);
                lista.add(o);
            }
            return lista;
        }catch(SQLException sqe) {
           System.out.println("Erro = " + sqe);
        }
        return null;
    }
}