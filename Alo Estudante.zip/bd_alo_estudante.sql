-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Nov-2023 às 03:49
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bd_alo_estudante`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `contrato`
--

CREATE TABLE `contrato` (
  `idCont` int(50) NOT NULL,
  `codCont` varchar(90) NOT NULL,
  `cnpjEmpre` varchar(255) NOT NULL,
  `cpfEstag` varchar(255) NOT NULL,
  `inicioContrato` varchar(10) NOT NULL,
  `terminoContrato` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `empresa`
--

CREATE TABLE `empresa` (
  `codEmpre` int(50) NOT NULL,
  `nome_empresa` varchar(70) NOT NULL,
  `cnpj` varchar(14) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `numero` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `telefone_empresa` varchar(20) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha_empresa` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `empresa`
--

INSERT INTO `empresa` (`codEmpre`, `nome_empresa`, `cnpj`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `telefone_empresa`, `descricao`, `email`, `senha_empresa`) VALUES
(1, 'aa', '40615101000191', 'a', '21', 'asd', 'asd', 'asd', '(43)423423423', 'teste', 'a@a.com', 123),
(2, 'Amazon', '15436940000103', 'Machado de assis', '1243', 'sul', 'Ososrio', 'paraiba', '(53)455235422', 'testy', 'q@a.com', 123);

-- --------------------------------------------------------

--
-- Estrutura da tabela `estagiario`
--

CREATE TABLE `estagiario` (
  `codEsta` int(50) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data` varchar(30) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `numero` varchar(6) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `senha` int(10) NOT NULL,
  `empresa` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `estagiario`
--

INSERT INTO `estagiario` (`codEsta`, `nome`, `data`, `cpf`, `rua`, `bairro`, `numero`, `cidade`, `estado`, `senha`, `empresa`) VALUES
(4, 'editar funciona', '12/12/2012', '54324120048', 'a', 'a', '1', 'a', 'Rio Grande do Sul', 123, NULL),
(5, 'abdair', '12/10/2000', '82338661052', 'a\'', 'a', '1', 'a', 'Bahia', 123, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `contrato`
--
ALTER TABLE `contrato`
  ADD PRIMARY KEY (`idCont`);

--
-- Índices para tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`codEmpre`);

--
-- Índices para tabela `estagiario`
--
ALTER TABLE `estagiario`
  ADD PRIMARY KEY (`codEsta`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `contrato`
--
ALTER TABLE `contrato`
  MODIFY `idCont` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `empresa`
--
ALTER TABLE `empresa`
  MODIFY `codEmpre` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `estagiario`
--
ALTER TABLE `estagiario`
  MODIFY `codEsta` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
