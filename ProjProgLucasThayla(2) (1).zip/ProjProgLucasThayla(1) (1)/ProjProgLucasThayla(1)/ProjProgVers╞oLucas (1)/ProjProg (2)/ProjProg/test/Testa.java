
import codigos.Contrato;
import codigos.Empresa;
import codigos.Estagiario;
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Marcos
 */
public class Testa {
  
    public static void testaRetorno(boolean b, String operacao) {
        if (b) { // testa se b == true
            System.out.println("Operacao realizada com sucesso !");
        } else {
            System.out.println("Falha na operacao de " + operacao);
        }
    }
    
    public static void main(String [] args){  
       
        Empresa apple = new Empresa("apple", "482974872749", "rua","121212", "sadsadsa","", 3243214);
        Empresa maracuja = new Empresa("maracuja", "34324323423", "rua2","12345599", "sss", "",23544325);
        
        LocalDate now = LocalDate.now();
        
        Estagiario paulo = new Estagiario("paulinho", now ,"1212121215115", "asdsad", "1212","24242", "1212sfdf", "fsdf",123);
        Estagiario renata = new Estagiario("renata", now ,"1212156887", "dsfkjsahfjkhfd", "1212","24242", "1212sfdf", "fsdf",4321);
        
        Contrato contrat1 = new Contrato(paulo, apple, now);
        
        boolean b = apple.addEmpregado(paulo);
        testaRetorno( b,"inserir na lista de empregados");
        b = apple.removeEmpregado(paulo);
        testaRetorno(b,"remove da lista de empregados");
        b = apple.addEmpregado(paulo);
        testaRetorno(b, "inseri na lista de empregados");
        
        System.out.println(contrat1.toString());
        System.out.println(contrat1.rompContrato());
    }
    
}
