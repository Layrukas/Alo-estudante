package codigos;


import codigos.Empresa;
import codigos.Estagiario;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Contrato implements Comparable{
    private int idCont;
    private String codCont;
    private Estagiario estag;
    private Empresa empres;
    private LocalDate iniciContrat;
    private LocalDate termContrat;

    public Contrato(String codCont,Estagiario estag, Empresa empres, LocalDate iniciContrat) {
        this.setEstag(estag);
        this.setEmpres(empres);
        this.setIniciContrat(iniciContrat);
    }

    public LocalDate getIniciContrat() {
        return iniciContrat;
    }
    
    public void setIniciContrat(LocalDate iniciContrat) {
        this.iniciContrat = iniciContrat;
    }
   
    public Estagiario getEstag() {
        return estag;
    }

    public void setEstag(Estagiario estag) {
        Objects.requireNonNull(estag, "Nao pode ser nulo");
        this.estag = estag;
    }

    public Empresa getEmpres() {
        return empres;
    }

    public void setEmpres(Empresa empres) {
        Objects.requireNonNull(empres, "Nao pode ser nulo");
        this.empres = empres;
    }

    public LocalDate getTermContrat() {
        return termContrat;
    }

    public void setTermContrat(LocalDate termContrat) {
        Objects.requireNonNull(termContrat, "Nao pode ser nulo");
        this.termContrat = termContrat;
    }
    
    public int getIdCont() {
        return idCont;
    }

    public void setIdCont(int idCont) {
        this.idCont = idCont;
    }

    public String getCodCont() {
        return codCont;
    }

    public void setCodCont(String codCont) {
        this.codCont = codCont;
    }
    
    public String getDataNascAsString(LocalDate a){
        LocalDate localDate = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String data = a.format(formatter);
        return data;
    }

    public String toString() {
        this.estag.setTrabalhando(true);
        return "Contrato \n" + "O presente contrato promove que " + this.estag.getNome() + " de cpf:" 
                + this.estag.getCpf() + " esta estagiando na empresa:" + this.empres.getNome_empresa() + "de cnpj:" + this.empres.getCnpj()
                + "no tempo de  meses, comecando na data:" + this.iniciContrat.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) 
                + " e terminando na data" + this.termContrat.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Contrato other = (Contrato) obj;
        if (!Objects.equals(this.estag, other.estag)) {
            return false;
        }
        if (!Objects.equals(this.empres, other.empres)) {
            return false;
        }
        if (!Objects.equals(this.iniciContrat, other.iniciContrat)) {
            return false;
        }
        if (!Objects.equals(this.termContrat, other.termContrat)) {
            return false;
        }
        return true;
    }
    
    

    public String rompContrato() {
        this.estag.setTrabalhando(false);
        return "O estagiario" + this.estag.getNome() + "nao trabalha mais aqui";
    }

    @Override
    public int compareTo(Object o) {
    Contrato c = (Contrato) o;
    int comp = this.estag.getCpf().compareTo(c.estag.getCpf());
    int comp2 = this.empres.getCnpj().compareTo(c.empres.getCnpj());
    if(comp == 0 && comp2 == 0) return 0;
    if(comp == 1) return (comp);
    if(comp == 1 && comp2 == 1) return 1;
    
    
    
        return 0;
    }
    
    

}


