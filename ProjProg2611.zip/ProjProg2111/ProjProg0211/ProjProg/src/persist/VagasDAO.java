/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;
import codigos.DAO;
import codigos.Empresa;
import codigos.Vagas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Objects;

/**
 *
 * @author ifrs
 */
public class VagasDAO implements DAO {
    private static VagasDAO vagadao;
    private static Connection conexao;
    
    public static VagasDAO getInstance() {
        if (vagadao == null) {
            vagadao = new VagasDAO();
        }
        return vagadao;
    }
    
    private VagasDAO() {
        ConexaoBD conexaoBD;

        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }
    
    @Override
    public boolean inserir(Object obj) {
        Objects.requireNonNull(obj);
        if(obj instanceof Vagas){
            Vagas vag = (Vagas) obj;
            String cod = vag.getCod();
            String nome = vag.getNome();
            String salario = vag.getSalario();
            String cnpjEmp = vag.getEmp().getCnpj();
            String sql = "INSERT INTO vagas (cod,nome,salario,cnpjEmp)" + "VALUES(?,?,?,?)";
            try{
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1, cod);
                pstmt.setString(2, nome);
                pstmt.setString(3,salario);
                pstmt.setString(4, cnpjEmp);
                pstmt.executeUpdate();
                return true;
            }catch(SQLException ex){
                 System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
        if (obj != null && obj instanceof String) {
            try {
                String cod = (String) obj;
                String sql = "DELETE FROM vagas WHERE cod = '" + cod + "'";
                Statement stmt = conexao.createStatement();
                int nreg = stmt.executeUpdate(sql);
                if (nreg > 0) {
                    return true;
                }
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        if (obj != null && obj instanceof Vagas) {
            try {
                Vagas p = (Vagas) obj;
                String sql = "UPDATE vagas SET cod = ? and nome = ? and salario = ? and cnpjEmpre = ? and cpfEstag = ? WHERE idVagas = ? ";
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1, p.getCod());
                pstmt.setString(2, p.getSalario());
                pstmt.setString(3, p.getEmp().getCnpj());
                pstmt.setString(4,p.getEst().getCpf());
                pstmt.executeUpdate();
                return true;
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public Object pesquisar(Object obj) {
        Objects.requireNonNull(obj);
        if (obj instanceof String) {
            try {
                String cod = (String) obj;
                String sql = "SELECT * FROM vagas WHERE cod = '" + cod + "'";
                Statement stmt = conexao.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                if(rs.isBeforeFirst()){
                    rs.next();
                    int idVag = rs.getInt(1);
                    String nome = rs.getString(3);
                    String salario = rs.getString(4);
                    String cnpjEmpre = rs.getString(5);
                    EmpresaDAO a;
                    a = EmpresaDAO.getInstance();
                    Empresa x = (Empresa) a.pesquisar(cnpjEmpre);
                    Vagas vaga = new Vagas(cod,nome,salario,x);
                    vaga.setIdVaga(idVag);
                    return vaga;
                }

            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return null;
    }
}
