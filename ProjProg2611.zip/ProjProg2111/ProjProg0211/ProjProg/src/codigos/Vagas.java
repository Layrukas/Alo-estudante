/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigos;

import java.util.Objects;

/**
 *
 * @author 08050486
 */
public class Vagas {
    
    private int idVaga;
    private String cod;
    private String nome;
    private String salario;
    private Empresa emp;
    private Estagiario est;

    public Vagas(String cod,String nome, String salario, Empresa emp) {
        this.setCod(cod);
        this.setNome(nome);
        this.setSalario(salario);
        this.setEmp(emp);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public Empresa getEmp() {
        return emp;
    }

    public void setEmp(Empresa emp) {
        this.emp = emp;
    }

    public Estagiario getEst() {
        return est;
    }

    public void setEst(Estagiario est) {
        this.est = est;
    }
    
    public int getIdVaga() {
        return idVaga;
    }

    public void setIdVaga(int idVaga) {
        this.idVaga = idVaga;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    @Override
    public String toString() {
        return "Vagas{" + "nome=" + nome + ", salario=" + salario + ", emp=" + emp + ", est=" + est + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + this.idVaga;
        hash = 53 * hash + Objects.hashCode(this.cod);
        hash = 53 * hash + Objects.hashCode(this.nome);
        hash = 53 * hash + Objects.hashCode(this.salario);
        hash = 53 * hash + Objects.hashCode(this.emp);
        hash = 53 * hash + Objects.hashCode(this.est);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vagas other = (Vagas) obj;
        if (this.idVaga != other.idVaga) {
            return false;
        }
        if (!Objects.equals(this.cod, other.cod)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.salario, other.salario)) {
            return false;
        }
        if (!Objects.equals(this.emp, other.emp)) {
            return false;
        }
        return Objects.equals(this.est, other.est);
    }

   
}
