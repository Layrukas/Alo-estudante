/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;

import codigos.Empresa;
import codigos.Estagiario;
import codigos.DAO;
import codigos.Contrato;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 *
 * @author 08050486
 */
public class ContratoDAO implements DAO {
    private static ContratoDAO contdao;
    private static Connection conexao;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
     public static ContratoDAO getInstance() {
        if (contdao == null) {
            contdao = new ContratoDAO();
        }
        return contdao;
    }
     private ContratoDAO() {
        ConexaoBD conexaoBD;
        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }

    @Override
    public boolean inserir(Object obj) {
        Objects.requireNonNull(obj);
        if(obj instanceof String){
            Contrato c = (Contrato) obj;
            String codCont = c.getCodCont();
            String cnpjEmpre = c.getEmpres().getCnpj();
            String cpfEstag = c.getEstag().getCpf();
            String iniciContrat = c.getDataNascAsString(c.getIniciContrat());
            String termContrat = c.getDataNascAsString(c.getTermContrat());
            
            String sql = "INSERT INTO contrato (codCont,nomeEmpre,nomeEstag,iniciContrat,termContrat)" + "VALUES (?,?,?,?,?)";
            
            try{
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1, codCont);
                pstmt.setString(2,cnpjEmpre);
                pstmt.setString(3,cpfEstag);
                pstmt.setString(4,iniciContrat);
                pstmt.setString(5,termContrat);
                pstmt.executeUpdate();
                return true;
            }catch(SQLException sqe){
                System.out.println("Erro = " + sqe);
            }
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
        if (obj != null && obj instanceof String) {
            try {
                String cod = (String) obj;
                String sql = "DELETE FROM contrato WHERE cod = '" + cod + "'";
                Statement stmt = conexao.createStatement();
                int nreg = stmt.executeUpdate(sql);
                if (nreg > 0) {
                    return true;
                }
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        if(obj !=  null && obj instanceof Contrato){
            try{
                Contrato p = (Contrato) obj;
                String codCont = p.getCodCont();
                String cnpjEmpre = p.getEmpres().getCnpj();
                String cpfEstag = p.getEstag().getCpf();
                
                String iniciContrat = p.getDataNascAsString(p.getIniciContrat());
                String termContrat = p.getDataNascAsString(p.getTermContrat());
                String sql = "UPDATE contrato SET cnpjEmpre = ? and cpfEstaag = ? and inicioContrato = ? and terminoContrato = ? WHERE codCont = ? ";
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1,cnpjEmpre);
                pstmt.setString(2,cpfEstag);
                pstmt.setString(3,iniciContrat);
                pstmt.setString(4,termContrat);
                pstmt.setString(5, codCont);
                pstmt.executeQuery(sql);
                return true;
            }catch (SQLException ex) {
                System.out.println("Erro = " + ex);
            }
        }
        return false;
    }

    @Override
    public Object pesquisar(Object obj) {
        Objects.requireNonNull(obj);
        if(obj instanceof String){
            try{
                String cod = (String) obj;
                String sql = "SELECT INTO contrato WHERE cod ='" + cod + "'";
                Statement stml = conexao.createStatement();
                ResultSet rs = stml.executeQuery(sql);
                if(rs.isBeforeFirst()){
                    rs.next();
                    int idCont = rs.getInt(1);
                    String codCont = rs.getString(2);
                    String cnpjEmp = rs.getString(3);
                    String cpfEst = rs.getString(4);
                    String iniciCont = rs.getString(5);
                    String termCont = rs.getString(6);
                    
                    LocalDate inicioC = LocalDate.parse(iniciCont, formatter);
                    LocalDate termC = LocalDate.parse(termCont,formatter);
                    
                    EmpresaDAO a;
                    a = EmpresaDAO.getInstance();
                    EstagiarioDAO b;
                    b = EstagiarioDAO.getInstance();
                    Estagiario est = (Estagiario) b.pesquisar(cpfEst);
                    Empresa emp = (Empresa) a.pesquisar(cnpjEmp);
      
                    
                    Contrato con= new Contrato(codCont,est,emp,inicioC); 
                    con.setTermContrat(termC);
                    con.setIdCont(idCont);
                    return con;
                }
                
        }catch(SQLException ex){
                System.out.println("Erro =" + ex);
        }
    }
        return null;
    } 
}
