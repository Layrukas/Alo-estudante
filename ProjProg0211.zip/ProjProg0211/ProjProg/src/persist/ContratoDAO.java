/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;

import codigos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author 08050486
 */
public class ContratoDAO implements DAO {
    private static ContratoDAO contdao;
    private static Connection conexao;
    
     public static ContratoDAO getInstance() {
        if (contdao == null) {
            contdao = new ContratoDAO();
        }
        return contdao;
    }
     private ContratoDAO() {
        ConexaoBD conexaoBD;
        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }
//     public boolean inserir(Object obj) {
//          if (obj != null && obj instanceof Empresa) {
//              Empresa e = (Empresa) obj;
//              String nome = e.getNome_empresa();
//              String cnpj = e.getCnpj();
//              Integer senha = e.getSenha();
//              String email = e.getEmail();
//              String descricao = e.getDescricao();
//              String rua = e.getRuaEmpre();
//              String bairro = e.getBairroEmpre();
//              String cidade = e.getCidadeEmpre();
//              String estado = e.getEstadoEmpre();
//              String numero = e.getNumeroEmpre();
//              String telefone = e.getTelefone_empresa();
//              
//              String sql = "INSERT INTO empresa (nome, cnpj, senha, email, descricao,rua,numero,bairro,cidade,estado,telefone)" + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
//              
//              try{
//                  PreparedStatement pstmt = conexao.prepareStatement(sql);
//                  pstmt.setString(1,nome);
//                  pstmt.setString(2, cnpj);
//                  pstmt.setInt(3, senha);
//                  pstmt.setString(4,email);
//                  pstmt.setString(5,descricao);
//                  pstmt.setString(6,rua);
//                  pstmt.setString(7,numero);
//                  pstmt.setString(8,cidade);
//                  pstmt.setString(9,estado);
//                  pstmt.setString(10,bairro);
//                  pstmt.setString(11,telefone);
//                  pstmt.executeUpdate();
//                  return true;
//              } catch(SQLException sqe){
//                  System.out.println("Erro = " + sqe);
//              }
//          }
//         return false;
//     }

     
    @Override
    public boolean inserir(Object obj) {
        Objects.requireNonNull(obj);
        if(obj instanceof String){
            Contrato c = (Contrato) obj;
            String nomeEmpre = c.getEmpres().getNome_empresa();
            String nomeEstag = c.getEstag().getNome();
            String iniciContrat = c.getDataNascAsString(c.getIniciContrat());
            String termContrat = c.getDataNascAsString(c.getTermContrat());
            
            String sql = "INSERT INTO contrato (nomeEmpre,nomeEstag,iniciContrat,termContrat)" + "VALUES (?,?,?,?)";
            
            try{
                PreparedStatement pstmt = conexao.prepareStatement(sql);
                pstmt.setString(1,nomeEmpre);
                pstmt.setString(2,nomeEstag);
                pstmt.setString(3,iniciContrat);
                pstmt.setString(4,termContrat);
                pstmt.executeUpdate();
                return true;
            }catch(SQLException sqe){
                System.out.println("Erro = " + sqe);
            }
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean editar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Object pesquisar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
