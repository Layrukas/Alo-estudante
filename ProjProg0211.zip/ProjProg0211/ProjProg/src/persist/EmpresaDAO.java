/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;
import codigos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author 08050486
 */
public class EmpresaDAO implements DAO {
     private static EmpresaDAO empdao;
    private static Connection conexao;

    public static EmpresaDAO getInstance() {
        if (empdao == null) {
            empdao = new EmpresaDAO();
        }
        return empdao;
    }
    
     private EmpresaDAO() {
        ConexaoBD conexaoBD;

        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }

     @Override
     public boolean inserir(Object obj) {
          if (obj != null && obj instanceof Empresa) {
              Empresa e = (Empresa) obj;
              String nome = e.getNome_empresa();
              String cnpj = e.getCnpj();
              Integer senha = e.getSenha();
              String email = e.getEmail();
              String descricao = e.getDescricao();
              String rua = e.getRuaEmpre();
              String bairro = e.getBairroEmpre();
              String cidade = e.getCidadeEmpre();
              String estado = e.getEstadoEmpre();
              String numero = e.getNumeroEmpre();
              String telefone = e.getTelefone_empresa();
              
              String sql = "INSERT INTO empresa (nome, cnpj, senha, email, descricao,rua,numero,bairro,cidade,estado,telefone)" + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
              
              try{
                  PreparedStatement pstmt = conexao.prepareStatement(sql);
                  pstmt.setString(1,nome);
                  pstmt.setString(2, cnpj);
                  pstmt.setInt(3, senha);
                  pstmt.setString(4,email);
                  pstmt.setString(5,descricao);
                  pstmt.setString(6,rua);
                  pstmt.setString(7,numero);
                  pstmt.setString(8,cidade);
                  pstmt.setString(9,estado);
                  pstmt.setString(10,bairro);
                  pstmt.setString(11,telefone);
                  pstmt.executeUpdate();
                  return true;
              } catch(SQLException sqe){
                  System.out.println("Erro = " + sqe);
              }
          }
         return false;
     }

    @Override
    public boolean excluir(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean editar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Object pesquisar(Object obj) {
        if(obj != null && obj instanceof String){
            try{
                String cnpj = (String) obj;
                String sql = "SELECT * FROM bd_alo_estudante WHERE cpf = '" + cnpj +"'";
                Statement stml = conexao.createStatement();
                ResultSet rs = stml.executeQuery(sql);
                if(rs.isBeforeFirst()){
                    rs.next();
                    int idEmp = rs.getInt(1);
                    String nome_empresa = rs.getString(2);
                    String rua =rs.getString(4);
                    String numero = rs.getString(5);
                    String bairro = rs.getString(6);
                    String cidade = rs.getString(7);
                    String estado = rs.getString(8);
                    String telefone = rs.getString(9);
                    String descricao = rs.getString(10);
                    String email = rs.getString(11);
                    Integer senha = rs.getInt(12);
                    
                    Empresa m = new Empresa(nome_empresa, cnpj,rua,numero,bairro,cidade,estado,telefone,email,descricao,senha);
                    m.setId(idEmp);
                    return m;
                }
            }catch(SQLException ex){
                System.out.println("Erro = "+ ex);
        }
      }
        return null;
    }
}
