package codigos;

import codigos.Estagiario;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Objects;

public class Empresa {
    
    private int idEmpre;
    private String nome_empresa;
    private String cnpj;
    private String ruaEmpre;
    private String bairroEmpre;
    private String numeroEmpre;
    private String cidadeEmpre;
    private String estadoEmpre; 
    private String telefone_empresa;
    private String email;
    private String descricao;
    private Integer senha;
    
    public Empresa(String nome_empresa, String cnpj,String ruaEmpre, String numeroEmpre,String bairroEmpre,String cidadeEmpre,String estadoEmpre, String telefone_empresa, String email,String descricao, Integer senha) {
        this.setNome_empresa(nome_empresa);
        this.setCnpj(cnpj);
        this.setRuaEmpre(ruaEmpre);
        this.setBairroEmpre(bairroEmpre);
        this.setNumeroEmpre(numeroEmpre);
        this.setCidadeEmpre(cidadeEmpre);
        this.setEstadoEmpre(estadoEmpre);
        this.setTelefone_empresa(telefone_empresa);
        this.setEmail(email);
        this.setDescricao(descricao);
        this.setSenha(senha);
    }
    
    public int getId() {
        return idEmpre;
    }

    public void setId(int idEmpre) {
        this.idEmpre = idEmpre;
    }

    public String getNome_empresa() {
        return nome_empresa;
    }

    public void setNome_empresa(String nome_empresa) {
        this.nome_empresa = nome_empresa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        Objects.requireNonNull(cnpj,"Nao pode ser nulo");
        this.cnpj = cnpj;
    }

    public String getRuaEmpre() {
        return ruaEmpre;
    }

    public void setRuaEmpre(String ruaEmpre) {
        this.ruaEmpre = ruaEmpre;
    }

    public String getBairroEmpre() {
        return bairroEmpre;
    }

    public void setBairroEmpre(String bairroEmpre) {
        this.bairroEmpre = bairroEmpre;
    }

    public String getNumeroEmpre() {
        return numeroEmpre;
    }

    public void setNumeroEmpre(String numeroEmpre) {
        this.numeroEmpre = numeroEmpre;
    }

    public String getCidadeEmpre() {
        return cidadeEmpre;
    }

    public void setCidadeEmpre(String cidadeEmpre) {
        this.cidadeEmpre = cidadeEmpre;
    }

    public String getEstadoEmpre() {
        return estadoEmpre;
    }

    public void setEstadoEmpre(String estadoEmpre) {
        this.estadoEmpre = estadoEmpre;
    }

    public String getTelefone_empresa() {
        return telefone_empresa;
    }

    public void setTelefone_empresa(String telefone_empresa) {
        Objects.requireNonNull(telefone_empresa,"nao pode ser nulo");
        this.telefone_empresa = telefone_empresa;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        Objects.requireNonNull(email,"nao pode ser nulo");
        this.email = email;
    }
    
     public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        Objects.requireNonNull(descricao,"nao pode ser nulo");
        this.descricao = descricao;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
         Objects.requireNonNull(senha,"nao pode ser nulo");
        this.senha = senha;
    }
    
    @Override
    public String toString() {
        return "Empresa{" + "idEmpre=" + idEmpre + ", nome_empresa=" + nome_empresa + ", cnpj=" + cnpj + ", ruaEmpre=" + ruaEmpre + ", bairroEmpre=" + bairroEmpre + ", numeroEmpre=" + numeroEmpre + ", cidadeEmpre=" + cidadeEmpre + ", estadoEmpre=" + estadoEmpre + ", telefone_empresa=" + telefone_empresa + ", email=" + email + ", descricao=" + descricao + ", senha=" + senha + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (this.idEmpre != other.idEmpre) {
            return false;
        }
        if (!Objects.equals(this.nome_empresa, other.nome_empresa)) {
            return false;
        }
        if (!Objects.equals(this.cnpj, other.cnpj)) {
            return false;
        }
        if (!Objects.equals(this.ruaEmpre, other.ruaEmpre)) {
            return false;
        }
        if (!Objects.equals(this.bairroEmpre, other.bairroEmpre)) {
            return false;
        }
        if (!Objects.equals(this.numeroEmpre, other.numeroEmpre)) {
            return false;
        }
        if (!Objects.equals(this.cidadeEmpre, other.cidadeEmpre)) {
            return false;
        }
        if (!Objects.equals(this.estadoEmpre, other.estadoEmpre)) {
            return false;
        }
        if (!Objects.equals(this.telefone_empresa, other.telefone_empresa)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        return Objects.equals(this.senha, other.senha);
    }
    
    
    
    
}
