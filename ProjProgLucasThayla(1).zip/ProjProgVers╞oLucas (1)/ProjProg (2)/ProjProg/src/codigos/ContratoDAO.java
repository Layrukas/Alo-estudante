package codigos;

import codigos.DAO;
import java.util.Iterator;
import java.util.Objects;
import java.util.TreeSet;

public class ContratoDAO implements DAO {
    TreeSet contra = new TreeSet<Contrato>();
    
    @Override
    public boolean inserir(Object obj) {
        Objects.requireNonNull(obj, " nao podem ser nulos");
        if(obj instanceof Contrato){
            Contrato a = (Contrato) obj;
            if(!contra.contains(a)) return false;
            return contra.add(a);
        }
        else return false;

    }

    @Override
    public boolean excluir(Object obj) {
        Objects.requireNonNull(obj, " nao podem ser nulos");
        if(obj instanceof String ){
            String cpf = (String) obj;
            Contrato a = (Contrato) pesquisar(cpf);
            if(a != null) return contra.remove(a);
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        Objects.requireNonNull(obj, " nao pode ser nulos");
        if(obj instanceof Contrato){
        Contrato a = (Contrato) obj;
        boolean p = excluir(a.getEstag().getCpf());
        if(p) return contra.add(a);
        }
        return false;
        
    }

    @Override
    //procurar apartir do cpf de uma pessoa, ja que um estagiario so pode ter um contrato com uma empresa
    public Object pesquisar(Object obj) {
        Objects.requireNonNull(obj, " nao podem ser nulos");
        if(obj instanceof String){
            String cpf = (String) obj;
            Iterator it = contra.iterator();
            while(it.hasNext()){
                Contrato a = (Contrato) it.next();
                if(a.getEstag().getCpf().equals(cpf)){
                    return a;
                }
            }
        }
        return null;
        
    }
    
    
}

