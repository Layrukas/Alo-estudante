package codigos;

import java.util.HashMap;
import java.util.Objects;

public class EstagiarioDAO implements DAO {
    private static EstagiarioDAO estdao;    
    private HashMap<String,Estagiario> m = new HashMap<>();
	//metodo para manter o objeto instanciado sendo o unico estanciado
        public static EstagiarioDAO getInstance() {
        if (estdao == null) {
            estdao = new EstagiarioDAO();
        }
        return estdao;   
    }
        
        @Override
	public boolean inserir(Object obj) {
		Objects.requireNonNull(obj, "Dados nao podem ser nulos");
		if (obj instanceof Estagiario) {

			Estagiario p = (Estagiario) obj;
			if (m.containsKey(p.getCpf()))
				return false;

			m.put(p.getCpf(), p);
			return true;
		}
		return false;
	}

	@Override
	// Em obj estar� o cpf da pessoa
	public boolean excluir(Object obj) {
		Objects.requireNonNull(obj, "O cpf nao poder nulo");
		if (obj instanceof Estagiario) {
			Estagiario p = (Estagiario) obj;
			m.remove(p.getCpf());
			return true;
		}
		return false;
	}

	@Override
	// Em obj estar� a pessoa com os dados atualizados exceto o cpf,
	// que vai servir de chave de busca
	public boolean editar(Object obj) {
		Objects.requireNonNull(obj, "Dados nao podem ser nulos");
		if (obj instanceof Estagiario) {
			Estagiario p = (Estagiario) obj;
			if (!m.containsKey(p.getCpf()))
				return false;
			m.put(p.getCpf(), p);
			return true;
		}
		return false;
	}

	@Override
    //Em obj estar� o cpf da pessoa
    public Object pesquisar(Object obj) {
        Objects.requireNonNull(obj, "O cpf nao poder nulo");
        if (obj instanceof String){
         String s = (String) obj;
         return  m.get(s);
        }
        return null;
            }
    
}

