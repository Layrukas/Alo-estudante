package codigos;

import codigos.Estagiario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class Empresa {
    
    private String nome_empresa;
    private String cnpj;
    private String endereco_empresa;
    private String telefone_empresa;
    private String email;
    private String vaga;
    private Integer senha;
    private ArrayList<String> vagas = new ArrayList<>();
    private HashMap<String, Estagiario> empregados = new HashMap<>();
    
    public Empresa(String nome_empresa, String cnpj, String endereco_empresa, String telefone_empresa, String email, Integer senha) {
        this.setNome_empresa(nome_empresa);
        this.setCnpj(cnpj);
        this.setEndereco_empresa(endereco_empresa);
        this.setTelefone_empresa(telefone_empresa);
        this.setEmail(email);
        this.setSenha(senha);
    }

    public String getNome_empresa() {
        return nome_empresa;
    }

    public void setNome_empresa(String nome_empresa) {
        this.nome_empresa = nome_empresa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco_empresa() {
        return endereco_empresa;
    }

    public void setEndereco_empresa(String endereco_empresa) {
        this.endereco_empresa = endereco_empresa;
    }

    public String getTelefone_empresa() {
        return telefone_empresa;
    }

    public void setTelefone_empresa(String telefone_empresa) {
        this.telefone_empresa = telefone_empresa;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        this.senha = senha;
    }
    
    public boolean addEmpregado(Estagiario esta){
        if(esta == null){
           Objects.requireNonNull(esta, "Nao pode ser nulo");
        }
        if(esta.isTrabalhando() == true) 
        {
            return false;
        }else
         empregados.put(esta.getCpf(), esta);
        return true;
    }
    
    public boolean removeEmpregado(Estagiario esta){
        return empregados.remove(esta.getCpf(),esta);
    }

    @Override
    public String toString() {
        return "Empresa{" + "nome_empresa=" + nome_empresa + ", cnpj=" + cnpj + ", endereco_empresa=" + endereco_empresa 
                + ", telefone_empresa=" + telefone_empresa + ", email=" + email + ", senha=" + senha + ", empregados=" + empregados + '}';
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (!Objects.equals(this.nome_empresa, other.nome_empresa)) {
            return false;
        }
        if (!Objects.equals(this.cnpj, other.cnpj)) {
            return false;
        }
        if (!Objects.equals(this.endereco_empresa, other.endereco_empresa)) {
            return false;
        }
        if (!Objects.equals(this.telefone_empresa, other.telefone_empresa)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.senha, other.senha)) {
            return false;
        }
        if (!Objects.equals(this.empregados, other.empregados)) {
            return false;
        }
        return true;
    }
    
    
}
