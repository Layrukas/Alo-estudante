package codigos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class EmpresaDAO implements DAO {
    private static EmpresaDAO empdao;
    private HashMap<String, Empresa> a = new HashMap<>();

    public static EmpresaDAO getInstance() {
        if (empdao == null) {
            empdao = new EmpresaDAO();
        }
        return empdao;   
    }
    
    @Override
    public boolean inserir(Object obj) {
        Objects.requireNonNull(obj, "Dados nao podem ser nulos");
        if (obj instanceof Empresa) {

            Empresa p = (Empresa) obj;
            if (a.containsKey(p.getCnpj())) {
                return false;
            }

            a.put(p.getCnpj(), p);
            return true;
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
        Objects.requireNonNull(obj, "O cpf nao poder nulo");
        if (obj instanceof Empresa) {
            Empresa p = (Empresa) obj;
            a.remove(p.getCnpj());
            return true;
        }
        return false;
    }

    @Override
    public boolean editar(Object obj) {
        Objects.requireNonNull(obj, "Dados nao podem ser nulos");
        if (obj instanceof Empresa) {
            Empresa p = (Empresa) obj;
            if (!a.containsKey(p.getCnpj())) {
                return false;
            }
            a.put(p.getCnpj(), p);
            return true;
        }
        return false;
    }

    @Override
    public Object pesquisar(Object obj) {
        Objects.requireNonNull(obj, "O cpf nao poder nulo");
        if (obj instanceof Empresa) {
            Empresa p = (Empresa) obj;
            return a.get(p.getCnpj());
        }
        return null;
    }
    
    public boolean checkLogin(Object obj, Integer senha){
        Objects.requireNonNull(obj, "O Cnpj nao poder nulo");
        Objects.requireNonNull(senha, "A senha nao poder nula");
        Empresa p = (Empresa) this.pesquisar(obj);
        if(a.containsKey(p.getSenha().equals(senha))) return true;
        else return false;
    }
}
