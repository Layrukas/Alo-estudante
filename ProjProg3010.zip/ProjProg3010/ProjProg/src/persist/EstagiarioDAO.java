/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persist;

import codigos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EstagiarioDAO implements DAO {
    private static EstagiarioDAO estdao;
    private static Connection conexao;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    
     public static EstagiarioDAO getInstance() {
        if (estdao == null) {
            estdao = new EstagiarioDAO();
        }
        return estdao;
    }
     
     private EstagiarioDAO() {
        ConexaoBD conexaoBD;

        try {
            conexaoBD = ConexaoBD.getInstance();
            conexao = ConexaoBD.getConexao();
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        } catch (SQLException ex) {
            //Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro = " + ex);
        }
    }

    @Override
    public boolean inserir(Object obj) {
        if (obj != null && obj instanceof Estagiario) {
             Estagiario es = (Estagiario) obj;
             Integer idEst = es.getIdEst();
              String nome = es.getNome();
              String cpf = es.getCpf();
              Integer senha = es.getSenha();
              String estado = es.getEstado();
              String cidade = es.getCidade();
              String bairro = es.getBairro();//temporario
              String rua = es.getRua();
              String numero = es.getNumero();
              LocalDate dataNasc = es.getDataNasc();
             
              String sql = "INSERT INTO estagiario (nome, cpf, senha, estado, cidade, bairro, rua, numero, dataNasc)" + "VALUES (?,?,?,?,?,?,?,?,?)";
              
              try{
                  PreparedStatement pstmt = conexao.prepareStatement(sql);
                  pstmt.setInt(1, idEst);
                  pstmt.setString(2,nome);
                  pstmt.setString(3,es.getDataNascAsString());
                  pstmt.setString(4, cpf);
                  pstmt.setString(5, rua);
                  pstmt.setString(6,bairro);
                  pstmt.setString(7,numero);
                  pstmt.setString(8,cidade);
                  pstmt.setString(9,estado);
                  pstmt.setInt(10,senha);
                  pstmt.executeUpdate();
                  return true;
              } catch(SQLException sqe){
                  System.out.println("Erro = " + sqe);
              }
        }
        return false;
    }

    @Override
    public boolean excluir(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean editar(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        @Override
    //Em obj estará o cpf
    public Object pesquisar(Object obj) {
        if (obj != null && obj instanceof String) {
            try {
                String cpf = (String) obj;
                String sql = "SELECT * FROM tbpessoa WHERE cpf = '" + cpf + "'";
                Statement stmt = conexao.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                if (rs.isBeforeFirst()) { //verifica se resultou algo da pesquisa
                    rs.next();
                    int idEst = rs.getInt(1);
                    String nome = rs.getString(2);
                    String dataNasc = rs.getString(3);
                    String rua = rs.getString(5);
                    String bairro = rs.getString(6);
                    String numero = rs.getString(7);
                    String cidade = rs.getString(8);
                    String estado = rs.getString(9);
                    Integer senha = rs.getInt(10);
                    
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate data = LocalDate.parse(dataNasc, formatter);
                    
                    Estagiario estag = new Estagiario(nome, data, cpf, rua, bairro, numero, cidade, estado, senha);
                    return estag;
                } 
            } catch (SQLException ex) {
                System.out.println("Erro = " + ex);
       }
    } 
        return null;
}    
}