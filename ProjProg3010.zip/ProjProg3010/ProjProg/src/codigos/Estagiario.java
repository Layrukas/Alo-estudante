package codigos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;



public class Estagiario {
    
    private int idEst;
    private String nome;
    private LocalDate dataNasc;
    private String cpf;
    private String rua;
    private String bairro;
    private String numero;
    private String cidade;
    private String estado;
    private Empresa emp;
    private Integer senha;
    private boolean trabalhando;
//
    public Estagiario(String nome, LocalDate dataNasc, String cpf, String rua, String bairro, String numero, String cidade, String estado, Integer senha) {
        this.setNome(nome);
        this.setDataNasc(dataNasc);
        this.setCpf(cpf);
        this.setRua(rua);
        this.setBairro(bairro);
        this.setNumero(numero);
        this.setCidade(cidade);
        this.setEstado(estado);
        this.setSenha(senha);
        this.trabalhando = false;
    }

     public int getIdEst() {
        return idEst;
    }

    public void setIdEst(int idEst) {
        this.idEst = idEst;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if(nome == null){
            Objects.requireNonNull(nome,"Não pode ser nulo!");
        }
        this.nome = nome;
    }

    public LocalDate getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(LocalDate dataNasc) {
        if(dataNasc == null){
            Objects.requireNonNull(dataNasc,"Não pode ser nulo!");
        }
        this.dataNasc = dataNasc;
    }
    
    public String getDataNascAsString(){
        LocalDate localDate = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String data = dataNasc.format(formatter);
        return data;
    }
    
    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        if(senha == null){
            Objects.requireNonNull(senha,"Não pode ser nulo!");
        }
        this.senha = senha;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
       
            Objects.requireNonNull(cpf,"Não pode ser nulo!");
        
        this.cpf = cpf;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        
            Objects.requireNonNull(rua,"Não pode ser nulo!");
        
        this.rua = rua;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
       
            Objects.requireNonNull(bairro,"Não pode ser nulo!");
        
        this.bairro = bairro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        
            Objects.requireNonNull(numero,"Não pode ser nulo!");
        
        this.numero = numero;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
      
            Objects.requireNonNull(cidade,"Não pode ser nulo!");
        
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        
            Objects.requireNonNull(estado,"Não pode ser nulo!");
        
        this.estado = estado;
    }

    public boolean isTrabalhando() {
        return trabalhando;
    }

    public void setTrabalhando(boolean trabalhando) {
        Objects.requireNonNull(trabalhando,"Não pode ser nulo!");
        this.trabalhando = trabalhando;
    } 

    @Override
    public String toString() {
        return "Estagiario{" + "nome=" + nome + ", dataNasc=" + dataNasc + ", cpf=" + cpf + ", rua=" + rua + ", bairro=" + bairro + ", numero=" + numero + ", cidade=" + cidade + ", estado=" + estado + ", trabalhando=" + trabalhando + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estagiario other = (Estagiario) obj;
        if (this.trabalhando != other.trabalhando) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.cpf, other.cpf)) {
            return false;
        }
        if (!Objects.equals(this.rua, other.rua)) {
            return false;
        }
        if (!Objects.equals(this.bairro, other.bairro)) {
            return false;
        }
        if (!Objects.equals(this.numero, other.numero)) {
            return false;
        }
        if (!Objects.equals(this.cidade, other.cidade)) {
            return false;
        }
        if (!Objects.equals(this.estado, other.estado)) {
            return false;
        }
        if (!Objects.equals(this.dataNasc, other.dataNasc)) {
            return false;
        }
        return true;
    }
    
    
          
}
