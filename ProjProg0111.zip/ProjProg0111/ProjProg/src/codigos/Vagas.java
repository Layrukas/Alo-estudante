/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigos;

import java.util.Objects;

/**
 *
 * @author 08050486
 */
public class Vagas {
    
    private String nome;
    private double salario;
    private Empresa emp;
    private Estagiario est;

    public Vagas(String nome, double salario, Empresa emp, Estagiario est) {
        setNome(nome);
        setSalario(salario);
        setEmp(emp);
        setEst(est);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Empresa getEmp() {
        return emp;
    }

    public void setEmp(Empresa emp) {
        this.emp = emp;
    }

    public Estagiario getEst() {
        return est;
    }

    public void setEst(Estagiario est) {
        this.est = est;
    }

    @Override
    public String toString() {
        return "Vagas{" + "nome=" + nome + ", salario=" + salario + ", emp=" + emp + ", est=" + est + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.salario) ^ (Double.doubleToLongBits(this.salario) >>> 32));
        hash = 97 * hash + Objects.hashCode(this.emp);
        hash = 97 * hash + Objects.hashCode(this.est);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vagas other = (Vagas) obj;
        if (Double.doubleToLongBits(this.salario) != Double.doubleToLongBits(other.salario)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.emp, other.emp)) {
            return false;
        }
        return Objects.equals(this.est, other.est);
    }
    
    
   
    
}
